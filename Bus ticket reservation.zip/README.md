# Bus-Booking-System-Application-Using-Python
The Bus Booking Application provides basic search, book, and cancel ticket operations build using python.
1.Create a databse i.e (Add bus will add the ongoing buses into the project database, intitially the database is left empty)
2.After adding the bus you can search the bus from  the main menu section.
3.Then you can book the bus providing the details of the passenger.
4.You can add more buses into the database when ever you want.
5.After booking the passenger details save the registeration id.
