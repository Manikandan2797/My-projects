from tkinter import *
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter.font import Font
from tkinter import messagebox
import pymysql


window=Tk()
window.config(bg="white")
window.geometry("1100x700")
window.resizable(0,0)


def conn_location():
    
    if fromcb.get()=='Select any one' or tocb.get()=='Select any one'or datecb.get()==''or monthcb.get()=='':
        messagebox.showerror('ERROR','All Fields Are Required')
    else:
        try:
            
            con=pymysql.connect(host='localhost',user='root',password='Admin@123')
            mycursor=con.cursor()
        except:
            messagebox.showerror('Error','Database connectivity issue TRY AGAIN')
            return

    

    
    try:
        
        query='use userdata'
        mycursor.execute(query)
      
    except:
        mycursor.execute('use userdata')

    query='select * from location where from=%s'
    mycursor.execute(query,(fromcb())) 

    query='insert into location(fromcb,tocb,datecb,monthcb)values(%s,%s,%s,%s)'
    mycursor.execute(query,(fromcb.get(),tocb.get(),datecb.get(),monthcb.get()))
    messagebox.showinfo('Success','created')

    
    con.commit()
    con.close()
        

image_0=Image.open('G:\\Manikandan\\Pythonproject\\redvan.png')
filename=ImageTk.PhotoImage(image_0)
background_label=Label(window,image=filename,height=500,width=500,bg='white')
background_label.place(x=270,y=100)

headlabel=Label(window,text="BUS TICKETS",font=("times",30,"bold"),bg="white",fg="#C21010")
headlabel.place(x=370,y=70)

fromlabel=Label(window,text="FROM",font=("times",10,"italic"),bg="white")
fromlabel.place(x=150,y=200)

fromcb=ttk.Combobox(window,width=40,state="readonly")
fromcb['values']=("Select any one","COIMBATORE","CHENNAI","BANGALORE")
fromcb.current(0)
fromcb.place(x=200,y=200)

tolabel=Label(window,text="TO",font=("times",10,"italic"),bg="white")
tolabel.place(x=560,y=200)
tocb=ttk.Combobox(window,width=40,state="readonly")
tocb['values']=("Select any one","COIMBATORE","CHENNAI","BANGALORE")
tocb.current(0)
tocb.place(x=600,y=200)

datelabel=Label(window,text="DATE",font=("times",10,"italic"),bg="white")
datelabel.place(x=350,y=350)
datecb=ttk.Combobox(window,width=10,state="readonly")
datecb['values']=("default","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")
datecb.current(0)
datecb.place(x=400,y=350)

monthlabel=Label(window,text="MONTH",font=("times",10,"italic"),bg="white",bd=0)
monthlabel.place(x=650,y=350)
monthcb=ttk.Combobox(window,width=10,state="readonly")
monthcb['values']=(" ","JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC")
monthcb.current(0)
monthcb.place(x=560,y=350)

bookbtn= Button(window,text="BOOK TICKETS",bg='#C21010',font=("times",12,"italic"),cursor='hand2',activebackground='#FAF8F1',fg='WHITE',bd=0,command=conn_location,padx=10,pady=10)
bookbtn.place(x=450,y=500)







 



window.mainloop()
