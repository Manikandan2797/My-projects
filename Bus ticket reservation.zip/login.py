from tkinter import *
from PIL import ImageTk,Image
from tkinter.font import Font
from tkinter import messagebox
import pymysql

def clear():
    userentry.delete(0,END)
    passentry.delete(0,END)
    
    

def login_user():
    
    if userentry.get()=='' or passentry.get()=='':
        messagebox.showerror('ERROR','All Fields Are Required')
    else:
        try:
            
            con=pymysql.connect(host='localhost',user='root',password='Admin@123')
            mycursor=con.cursor()
        except:
            messagebox.showerror('Error','Database connectivity issue TRY AGAIN')
            return
    try:
        
        query='use userdata'
        mycursor.execute(query)
        
    except:
        mycursor.execute('use userdata')

    query='select * from data where username=%s and password=%s'
    mycursor.execute(query,(userentry.get(),passentry.get()))

    row=mycursor.fetchone()
    if row ==None:
        messagebox.showerror('Error','Invalid User name and Password')

    else:
        messagebox.showinfo('Success','Login is success')
        
        con.commit()
        con.close()
        clear()
    window.destroy()
    import Bus_Booking_System

    
def passw():
    window.destroy()
    import password
    
def signup():
    window.destroy()
    import signup
    
window=Tk()
window.geometry("1100x600")
window.resizable(0,0)
window.title("Project")
window.config(bg='white')
myfont=Font(family="times",size=12,weight="bold")
myfont1=Font(family="times",size=20,weight="bold")
myfont2=Font(family="Climate Crisis",size=24,slant='italic')
frame1=Frame(window,highlightbackground="white",highlightthickness=2,bg="#EDF1D6",padx=0,pady=0)
frame1.grid(row=0,column=0,padx=0,pady=10)

image_0=Image.open('redvan.png')
filename=ImageTk.PhotoImage(image_0)
background_label=Label(frame1,image=filename,height=500,width=500,bg='white')
background_label.grid(row=1,column=0)
lab4=Label(window,text="RED BUS\n\n",font=myfont2,bg="white",fg="#C21010")
lab4.place(x=180,y=45)

lab4=Label(window,text="LOG IN TO YOUR ACCOUNT",font=myfont1,bg="white",fg="#C21010")
lab4.place(x=550,y=45)
userlabel=Label(window,text="USER NAME",font=myfont,bg="white",fg="#C21010")
userlabel.place(x=550,y=200)
userentry=Entry(window,width=40,bg="white")
userentry.place(x=700,y=200)
passlabel=Label(window,text="PASSWORD",font=myfont,bg="white",fg="#C21010")
passlabel.place(x=550,y=250)
passentry=Entry(window,width=40,bg="white",show="*")
passentry.place(x=700,y=252)
btn2 = Button(window,text="Forget my password?",bg='white',activebackground='white',bd=0,fg='#DD5353',width=20,cursor='hand2',command=passw)
btn2.place(x=535,y=300)
frame2=Frame(window,width=110,bg="red")
frame2.place(x=550,y=318)
btn3 = Button(window,text="Create an account? Signup",bg='white',activebackground='white',bd=0,fg='#DD5353',width=20,cursor='hand2',command=signup)
btn3.place(x=800,y=400)
frame3=Frame(window,width=140,bg="red")
frame3.place(x=804,y=420)

btn1 = Button(window,text="LOG IN",bg='#C21010',font=myfont,cursor='hand2',activebackground='#FAF8F1',fg='WHITE',bd=0,padx=10,pady=10,command=login_user)
btn1.place(x=858,y=332)

window.mainloop()


    

