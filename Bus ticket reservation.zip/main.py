
from tkinter import *
from PIL import ImageTk,Image
from tkinter.font import Font

def signup_page():
    homepage.destroy()
    import signup
def login():
    homepage.destroy()
    import login
    

homepage=Tk()
homepage.geometry("1300x700")
homepage.config(bg='white')
homepage.resizable(0,0)
myfont=Font(family="times",size=10,slant="italic")
myfont1=Font(family="times",size=15)
bgimage=ImageTk.PhotoImage(file="homepage.jpg")

bglabel=Label(homepage,image=bgimage,bg='white')
bglabel.place(x=500,y=210)
btn1 = Button(homepage,text="LOGIN",bg='white',bd=0,font=myfont1,fg='#DD5353',width=20,cursor='hand2',activebackground='white',command=login)
btn1.place(relx=0.42,rely=0.72)
frame1=Frame(homepage,width=60,bg="red")
frame1.place(x=628,y=528)
btn2 = Button(homepage,text="Create a new account?  Sign up",bg='white',font=myfont,activebackground='white',bd=0,fg='#DD5353',width=40,cursor='hand2',command=signup_page)
btn2.place(relx=0.40,rely=0.79)
frame2=Frame(homepage,width=42,bg="red")
frame2.place(x=710,y=570)



homepage.mainloop()
