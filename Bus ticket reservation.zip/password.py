from tkinter import *
from PIL import ImageTk,Image
from tkinter.font import Font
from tkinter import messagebox
import pymysql

def clear():
    userentry.delete(0,END)
    phonentry.delete(0,END)
    npassentry.delete(0,END)
    cpassentry.delete(0,END)
    window.destroy()
    import login
    



def pass_conn():
    
    if userentry.get()=='' or phonentry.get()=='' or npassentry.get()=='' or cpassentry.get()=='':
        messagebox.showerror('ERROR','All Fields Are Required')
    elif npassentry.get()!= cpassentry.get():
        messagebox.showerror('ERROR','Password Mismatch')
    else:
        try:
            
            con=pymysql.connect(host='localhost',user='root',password='Admin@123')
            mycursor=con.cursor()
        except:
            messagebox.showerror('Error','Database connectivity issue TRY AGAIN')
            return
    try:
        
        query='use userdata'
        mycursor.execute(query)
        
    except:
        mycursor.execute('use userdata')
    
    

    query='select * from data where username=%s'
    mycursor.execute(query,(userentry.get()))

    row=mycursor.fetchone()
    if row ==None:
        messagebox.showerror('Error','Invalid User name and Password',parent=window)
       
    

    else:
        
        query='update data set password=%s where username=%s'
        mycursor.execute(query,(npassentry.get(),userentry.get()))
        messagebox.showinfo('password reset','Password Reset Successfull\nBack to Login page',parent=window)
        
        con.commit()
        con.close()
        clear()

    
        
        
   
        
    
    
        

window=Tk()
window.geometry("650x500")
window.resizable(0,0)
window.title("Project")
window.config(bg='white')
myfont=Font(family="times",size=14,weight="bold")
myfont1=Font(family="times",size=20,weight="bold")
myfont2=Font(family="Climate Crisis",size=24,slant='italic')
bgimage=ImageTk.PhotoImage(file="redbus3.jpg")

bglabel=Label(window,image=bgimage,bg='white')
bglabel.place(x=220,y=15)

lab4=Label(window,text="CHANGE YOUR PASSWORD\n",font=myfont,bg="white",fg="#C21010")
lab4.place(x=180,y=140)
userlabel=Label(window,text="USER NAME*",font=myfont,bg="white",fg="#C21010")
userlabel.place(x=110,y=200)
userentry=Entry(window,width=40,bg="white")
userentry.place(x=303,y=202)
phonlabel=Label(window,text="PHONE NUMBER",font=myfont,bg="white",fg="#C21010")
phonlabel.place(x=110,y=250)
phonentry=Entry(window,width=40,bg="white")
phonentry.place(x=303,y=252)
npasslabel=Label(window,text="NEW PASSWORD*",font=myfont,bg="white",fg="#C21010")
npasslabel.place(x=110,y=300)
npassentry=Entry(window,width=32,bg="white",show="*")
npassentry.place(x=350,y=302)
cpasslabel=Label(window,text="CONFIRM PASSWORD*",font=myfont,bg="white",fg="#C21010")
cpasslabel.place(x=110,y=350)
cpassentry=Entry(window,width=32,bg="white",show="*")
cpassentry.place(x=350,y=352) 
btn1 = Button(window,text="SUBMIT",bg='#C21010',font=myfont,cursor='hand2',activebackground='#FAF8F1',fg='WHITE',bd=0,padx=5,pady=5,command=pass_conn)
btn1.place(x=443,y=400)

window.mainloop()


    

