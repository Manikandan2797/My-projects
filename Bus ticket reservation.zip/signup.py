from tkinter import *
from PIL import ImageTk,Image
from tkinter.font import Font
from tkinter import messagebox
import pymysql

def clear():
    userentry.delete(0,END)
    emailentry.delete(0,END)
    phonentry.delete(0,END)
    passentry.delete(0,END)
    cpassentry.delete(0,END)

def con_database():
    if emailentry.get()=='' or userentry.get()=='' or phonentry.get()=='' or passentry.get()=='' or cpassentry.get()=='':
        messagebox.showerror('ERROR','All Fields Are Required')
    elif passentry.get()!= cpassentry.get():
        messagebox.showerror('ERROR','Password Mismatch')
    else:
        try:
            
            con=pymysql.connect(host='localhost',user='root',password='Admin@123')
            mycursor=con.cursor()
        except:
            messagebox.showerror('Error','Database connectivity issue TRY AGAIN')
            return
    try:
        query='create database userdata'
        mycursor.execute(query)
        query='use userdata'
        mycursor.execute(query)
        query='create table data(id int auto_increment primary key not null,username varchar(100),email varchar(50),phonenumber varchar(50),password varchar(20))'
        mycursor.execute(query)
    except:
        mycursor.execute('use userdata')

    query='select * from data where username=%s'
    mycursor.execute(query,(userentry.get()))

    row=mycursor.fetchone()

    if row !=None:
        messagebox.showerror('Error','User name already exists')

    else:
        query='insert into data(username,email,phonenumber,password)values(%s,%s,%s,%s)'
        mycursor.execute(query,(userentry.get(),emailentry.get(),phonentry.get(),passentry.get()))
        con.commit()
        con.close()
        messagebox.showinfo('Success','Account Created')
        clear()
        
    

    
    window.destroy()
    import login
    

    
    
            
        
        
    
def login_page():
    window.destroy()
    import login

    
window=Tk()
window.geometry("1100x600")
window.resizable(0,0)
window.title("Project")

window.config(bg='white')
myfont=Font(family="times",size=12,weight="bold")
myfont1=Font(family="times",size=20,weight="bold")
myfont2=Font(family="Climate Crisis",size=24,slant='italic')
frame1=Frame(window,highlightbackground="white",highlightthickness=2,bg="#EDF1D6",padx=0,pady=0)
frame1.grid(row=0,column=0,padx=0,pady=10)

image_0=Image.open('G:\\Manikandan\\Pythonproject\\redvan.png')
filename=ImageTk.PhotoImage(image_0)
background_label=Label(frame1,image=filename,height=500,width=500,bg='white')
background_label.grid(row=1,column=0)
lab4=Label(window,text="RED BUS\n\n",font=myfont2,bg="white",fg="#C21010")
lab4.place(x=180,y=45)

lab4=Label(window,text="CREATE AN ACCOUNT\n\n",font=myfont1,bg="white",fg="#C21010")
lab4.place(x=600,y=45)
userlabel=Label(window,text="USERNAME*",font=myfont,bg="white",fg="#C21010")
userlabel.place(x=550,y=150)
userentry=Entry(window,width=40,bg="white")
userentry.place(x=700,y=152)
emaillabel=Label(window,text="E-MAIL",font=myfont,bg="white",fg="#C21010")
emaillabel.place(x=550,y=200)
emailentry=Entry(window,width=40,bg="white")
emailentry.place(x=700,y=202)
phonlabel=Label(window,text="PHONE NUMBER",font=myfont,bg="white",fg="#C21010")
phonlabel.place(x=550,y=250)
phonentry=Entry(window,width=40,bg="white")
phonentry.place(x=700,y=252)
passlabel=Label(window,text="PASSWORD*",font=myfont,bg="white",fg="#C21010")
passlabel.place(x=550,y=300)
passentry=Entry(window,width=40,bg="white",show="*")
passentry.place(x=700,y=302)
cpasslabel=Label(window,text="CONFIRM PASSWORD*",font=myfont,bg="white",fg="#C21010")
cpasslabel.place(x=550,y=350)
cpassentry=Entry(window,width=32,bg="white",show="*")
cpassentry.place(x=750,y=352)
back_button = Button(window,text="Back to login page",bg='white',cursor='hand2',activebackground='white',fg='red',bd=0,command=login_page)
back_button.place(x=550,y=380)
btn1 = Button(window,text="SIGN UP",bg='#C21010',font=myfont,cursor='hand2',activebackground='#FAF8F1',fg='WHITE',bd=0,padx=10,pady=10,command=con_database)
btn1.place(x=858,y=452)

window.mainloop()


    

